require('assistant-plugins').start(__dirname);
